package models;

public enum TipusContingut {
    GAMER, HUMOR, CIÈNCIA;
}
